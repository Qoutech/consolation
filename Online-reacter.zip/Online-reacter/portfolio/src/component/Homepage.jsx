import React from 'react'
import About from '../assets/about.png'
import Image from '../assets/image.png'
function Homepage() {
  return (
    <>
         <div className='hero'>
        <div className="container text-light text-center pt-5">
        <h1 className='mt-5 pt-5'>Easy & Quick Cargo. Shipping Services</h1>
        <p className={{fontsize:'24px'}} >Book low-cost sea freight shipping services. Get an instant quote.</p>
        <a href="" className="btn btn-danger">Track Goods</a>
        </div>
    </div>


    <div className="container pt-5">
        <div className="text-center ">
            <h2>Welcome to Crystal Shipment</h2>
            <div className="bg-red mx-auto"></div>
            <p className='pt-3'>Crystal Shipment is more than logistics. We can also optimize your packaging, manage your materials sourcing, and so much more.</p>
        </div>
        <div className="row">
            <div className="col-md-6">
                <img src={About} alt=""className='img-fluid rounded' />
            </div>
            <div className="col-md-6">
                <p className='text-danger'>TRANSPORTATION COMPANY</p>
                <h2>We Provide Full Range Logistics Solution</h2>
                <p>We strongly believe that pursuing all of these goals is in our interest and in the interest of all of our stakeholders – customers, employees, investors, and the planet as a whole. We add value to cargo people’s interaction with us, with excellent services or products. Engaging our employees and nurturing investment in the stock holds market, we show concern.</p>
                <a href="" className="btn btn-danger">Learn more</a>
            </div>
        </div>
    </div>
    <div className="container pt-5 ">
        <div className="text-center">
        <p className="text-danger">TYPES OF LOGISTIC</p>
        <h2>Covering All Logistics Fields</h2>
        </div>
        <div className="row">
            <div className="col-md-4">
                <div className='card'>
                    <img src={Image} alt="" />
                <div className="card-body">
                        <h5 className="card-title">Air Freight</h5>
                        <p className="card-text">As a leader in global air freight forwarding, OIA Global excels in providing tailored transportation.. <a href="" className="text-danger text-decoration-none">Read More</a></p>
                </div>
                </div>
            </div>
            <div className="col-md-4">
                <div className='card'>
                    <img src={Image} alt="" />
                <div className="card-body">
                        <h5 className="card-title">Air Freight</h5>
                        <p className="card-text">As a leader in global air freight forwarding, OIA Global excels in providing tailored transportation.. <a href="" className="text-danger text-decoration-none">Read More</a></p>
                </div>
                </div>
            </div>

            <div className="col-md-4">
                <div className='card'>
                    <img src={Image} alt="" />
                <div className="card-body">
                        <h5 className="card-title">Air Freight</h5>
                        <p className="card-text">As a leader in global air freight forwarding, OIA Global excels in providing tailored transportation.. <a href="" className="text-danger text-decoration-none">Read More</a></p>
                </div>
                </div>
            </div>
        </div>
    </div>
    </>
   
    
  )
}

export default Homepage