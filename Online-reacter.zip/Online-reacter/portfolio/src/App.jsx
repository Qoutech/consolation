import { useState } from 'react' 
import Header from './component/Header'
import Footer from './component/Footer'
import Homepage from './component/Homepage'
import { BrowserRouter as Router ,Routes, Route} from "react-router-dom";

function App() {
  return (
    <>
    <Header/>
    <Router>
      <Routes>
       <Route exact path='/'element={ <Homepage/>}/>
      </Routes>
    </Router>
    <Footer/>
    </>
  )
}

export default App
